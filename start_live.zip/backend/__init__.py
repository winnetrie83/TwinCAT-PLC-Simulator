"""PLC Simulation Lab core."""
